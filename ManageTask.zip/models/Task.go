package models

type Task struct {
	Name string `json:"Name"`
}
