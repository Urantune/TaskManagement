package main

import (
	"ManageTask/handlers"
	"ManageTask/repository"
	"log"

	"github.com/gin-gonic/gin"
)

func main() {

	if err := repository.Connect(); err != nil {
		log.Fatal("DB connect failed:", err)
	}

	r := gin.Default()

	r.POST("/login", handlers.Login)

	r.POST("/register", handlers.Register)

	r.Run(":8080")

}
