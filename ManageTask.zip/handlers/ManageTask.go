package handlers

import (
	"ManageTask/models"
	"fmt"

	"github.com/gin-gonic/gin"
)

func ImportData(c *gin.Context) {
	var task models.Task
	c.ShouldBindJSON(&task)
	fmt.Println(task.Name)
}
